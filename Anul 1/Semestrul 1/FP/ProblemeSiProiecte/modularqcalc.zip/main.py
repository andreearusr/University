'''
Created on Oct 27, 2016

@author: istvan
'''
from ui.console import run

run()

