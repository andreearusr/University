def f():
    pass